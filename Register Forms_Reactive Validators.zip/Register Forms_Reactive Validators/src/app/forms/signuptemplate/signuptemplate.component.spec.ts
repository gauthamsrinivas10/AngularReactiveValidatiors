import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SignuptemplateComponent } from './signuptemplate.component';

describe('SignuptemplateComponent', () => {
  let component: SignuptemplateComponent;
  let fixture: ComponentFixture<SignuptemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SignuptemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SignuptemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
