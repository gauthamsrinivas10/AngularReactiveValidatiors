import { Component, OnInit } from '@angular/core';
import ISignup from 'src/app/interface/signup';
import { SignupService } from 'src/app/services/signup.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'employee-signuptemplate',
  templateUrl: './signuptemplate.component.html',
  styleUrls: ['./signuptemplate.component.css']
})
export class SignuptemplateComponent implements OnInit {
 
  form : ISignup = {
    fullName : "",
    phone : "" ,
    email : "" ,
    password : "",
    confirmpassword : ""
  }
  constructor(private signupform : SignupService) { }

  ngOnInit(): void {
  }
  signup(form : NgForm){
    console.log(this.form, form)
    this.signupform.signup(this.form).subscribe(()=>{
alert("New product added");
this.form = {
  fullName : "",
    phone : "",
    email : "" ,
    password : "",
    confirmpassword : ""

}
    
  })
  }
}
