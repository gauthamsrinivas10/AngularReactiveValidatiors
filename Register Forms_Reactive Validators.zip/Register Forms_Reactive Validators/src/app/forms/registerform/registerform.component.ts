import { Component, OnInit , Input } from '@angular/core';
import IRegister from 'src/app/interface/register';
import { RegisterService } from 'src/app/services/register.service';
import { FormControl, FormGroup, AbstractControl , Validators} from '@angular/forms';
import { Router } from '@angular/router'
import CompareValidator from 'src/app/validators/compare';

@Component({
  selector: 'employee-registerform',
  templateUrl: './registerform.component.html',
  styleUrls: ['./registerform.component.css']
})
export class RegisterformComponent implements OnInit {
  
  form = new FormGroup({
    fullName :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32) ]),
    phone :new  FormControl('',[Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(12), Validators.required ]),
    email :new  FormControl('' , [Validators.required , Validators.minLength(4), Validators.maxLength(32), Validators.email ]),
    password :new  FormControl('', [Validators.required , Validators.minLength(6), Validators.maxLength(32) ]),
    confirmpassword :new  FormControl('' , [Validators.required , Validators.minLength(6), Validators.maxLength(32) ]),
    address :new  FormControl('', [Validators.required , Validators.minLength(1), Validators.maxLength(50) ]),
    city :new  FormControl('' , [Validators.required , Validators.minLength(2), Validators.maxLength(32) ]),
  }, [CompareValidator("password" , "confirmpassword")] )
  constructor(private registerform : RegisterService , private router : Router) { }
  @Input() firstName !: string;
  ngOnInit(): void {
    // this.registerform.getRegisterUsers(this.firstName).subscribe((data)=>{
    //   console.log(data);
    //   this.form.patchValue(data);
    // }
    // )
  }

  registerForm(){
    console.log(this.form.value)
    this.registerform.register(this.firstName ,this.form.value).subscribe((data)=>{
alert("New product added");
this.router.navigateByUrl(`/register/${this.firstName}`)
    
  })
}
get fullName() : AbstractControl | null {
  return this.form.get("fullName")
}
get email() : AbstractControl | null {
  return this.form.get("email")
}
get address() : AbstractControl | null {
  return this.form.get("address")
}
get city() : AbstractControl | null {
  return this.form.get("city")
}
get phone() : AbstractControl | null {
  return this.form.get("phone")
}
get password() : AbstractControl | null {
  return this.form.get("password")
}
get confirmpassword() : AbstractControl | null {
  return this.form.get("confirmpassword")
}

get editForm() {
  return this.form
}
}
