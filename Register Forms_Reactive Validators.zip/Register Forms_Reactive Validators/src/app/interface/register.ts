export default interface IRegister {
    "fullName": string
    "email": string
    "address": string
    "city": string
    "phone": string
    "password": string
    "confirmpassword": string    
}